import { ImageDirective } from './image.directive';

describe('ImageDirective', () => {
  it('should create an instance', () => {
    const directive = new ImageDirective();
    expect(directive).toBeTruthy();
  });
});
