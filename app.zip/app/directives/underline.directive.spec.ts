import { UnderlineDirective } from './underline.directive';

describe('UnderlineDirective', () => {
  it('should create an instance', () => {
    const directive = new UnderlineDirective();
    expect(directive).toBeTruthy();
  });
});
