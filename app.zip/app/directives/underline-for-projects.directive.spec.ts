import { UnderlineForProjectsDirective } from './underline-for-projects.directive';

describe('UnderlineForProjectsDirective', () => {
  it('should create an instance', () => {
    const directive = new UnderlineForProjectsDirective();
    expect(directive).toBeTruthy();
  });
});
