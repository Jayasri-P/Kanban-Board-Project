export class User1{
    userEmail:any=""
    password:any=""
    userName:any=""
}