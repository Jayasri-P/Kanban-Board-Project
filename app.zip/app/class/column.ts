export class Column {
    columnId:any;
    columnName:any;
    taskList:Task[];
    constructor(){
        this.columnId="";
        this.columnName="";
        this.taskList=[];
    }
}
