import { ProjectMember } from './project-member';

describe('ProjectMember', () => {
  it('should create an instance', () => {
    expect(new ProjectMember()).toBeTruthy();
  });
});
