import { Column } from './column';

describe('Column', () => {
  it('should create an instance', () => {
    expect(new Column()).toBeTruthy();
  });
});
