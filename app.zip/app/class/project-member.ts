export class ProjectMember {
    memberEmail:any;
    memberName:any;
    noOfTask:any;

    constructor(){
        this.memberEmail="";
        this.memberName="";
        this.noOfTask="";
    }
}
