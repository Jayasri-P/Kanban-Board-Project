package com.kanbanboardproject.kanbanservice.service;

import com.kanbanboardproject.kanbanservice.domain.Project;

public interface ProjectService {
    Project saveProject(Project project);
   // Project getProject(String projectName);
}
